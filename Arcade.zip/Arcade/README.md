### GAME-ROOM
##### MAME Arcade Launcher
##### UI for your MAME ROMS, create launcher w/ python3 arcade.py
##### Change these vars for your setup, edit arcade.qml

* gameBin
* romPath
* gameIconsPath
* The order matters on these
    * gameTitles
    * gameRoms
    * gameIcons

#### Notes
* ESC will quit app
* MAME required
* MAME ROMS/BIOS required

<img alt="preview" src="preview.png" width="640">
