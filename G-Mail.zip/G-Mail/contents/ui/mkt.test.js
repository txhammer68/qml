 property var dowPercentChange : ((finData.market["^DJI"].previousClose.toFixed(2) - finData.market["^DJI"].close.slice(-1)[0].toFixed(2))/finData.market["^DJI"].previousClose.toFixed(2)*100).toFixed(2)
    property var nasdaqPercentChange : ((finData.market["^IXIC"].previousClose.toFixed(2) - finData.market["^IXIC"].close.slice(-1)[0].toFixed(2))/finData.market["^IXIC"].previousClose.toFixed(2)*100).toFixed(2)
    property var sp500PercentChange : ((finData.market["^GSPC"].previousClose.toFixed(2) - finData.market["^GSPC"].close.slice(-1)[0].toFixed(2))/finData.market["^GSPC"].previousClose.toFixed(2)*100).toFixed(2)






    // (FV − IV) ÷ IV × 100
        // text:isPositive(Math.round(finData.market[finSymbols[index]].close.slice(-1)[0].toFixed(2)-finData.market[finSymbols[index]].previousClose.toFixed(2))) ? "▲":"▼"
        var dowPercentChange = ((market["^DJI"].close.slice(-1)[0].toFixed(2)-market["^DJI"].previousClose.toFixed(2)) / market["^DJI"].previousClose.toFixed(2)*100).toFixed(2)

        var nasdaqPercentChange = ((market["^IXIC"].close.slice(-1)[0].toFixed(2) - market["^IXIC"].previousClose.toFixed(2))/market["^IXIC"].previousClose.toFixed(2)*100).toFixed(2)

        var sp500PercentChange = ((market["^GSPC"].close.slice(-1)[0].toFixed(2) - market["^GSPC"].previousClose.toFixed(2))/market["^GSPC"].previousClose.toFixed(2)*100).toFixed(2)

        if (dowPercentChange < -1.15 || nasdaqPercentChange < -1.95 || sp500PercentChange < -1.95  ) {
            panelIcon="stock_dialog-error"
            tx1.text=dowPercentChange
        }

         if (dowPercentChange > 1.95 || nasdaqPercentChange > 1.95 || sp500PercentChange > 1.95  ) {
            panelIcon="vcs-normal"
        }
