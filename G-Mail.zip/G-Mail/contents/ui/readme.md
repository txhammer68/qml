
### G-Mail widget
* GetData.qml
  * G-Mail unread messages
  * Market data
  * Sports scores data

### G-Mail
Using python to get gmail unread message count

### Using ESPN API to get sports scores
* Scores.qml
* MLB/NBA

### Using Yahoo Finance API to get market data
* Stocks.qml

### System Timer get data every 20 mins
* G-Mail (constant)
* Scores (variable) only when game active
* Stocks (variable) only when market open (M-F)
