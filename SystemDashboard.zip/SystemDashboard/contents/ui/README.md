
## Dashboard readme

* os-info.sh create a startup script that checks drive SMART status and collects system info at boot time
    * creates osInfo.json
    * contains hostname, distro,extIP,intIP,SMART status for /dev/sda/sdb/sdc,firewall status from service iptables
* reads /tmp/osInfo.json when widget created
* widget shows error messages when any of the following occur:
    * SMART status failed for any drive
    * low RAM less than 2 GB
    * high CPU Temp > 240 F
    * low disk space < 10GB
