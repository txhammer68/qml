#!/bin/bash
set -e
curl -s --retry-all-errors --retry 3 --retry-delay 5 -X GET "https://search.api.cnn.io/content?q=news&sort=newest&category=business,politics,markets,world,health,sports&size=6"  -H  "accept: application/json" -o /tmp/cnn.json
# DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd)"
# echo $DIR
# echo -e $(date)  - CNN update >> ${DIR}/cnn.log
exit
