#!/bin/bash
set -e
cd /home/data/projects/gmail
python3 gcalEvents.py
exit
