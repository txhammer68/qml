from __future__ import print_function;
import pickle
import os.path
import json
import datetime
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.errors import HttpError

# If modifying these scopes, delete the file token.json.

def calEvents():
    SCOPES = ['https://www.googleapis.com/auth/calendar.readonly']
    """Shows basic usage of the Google Calendar API.
    Prints the start and name of the next 10 events on the user's calendar.
    """
    creds = None
    # The file token.json stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open('token.json', 'w') as token:
            token.write(creds.to_json())

    try:
        service = build('calendar', 'v3', credentials=creds)

        # Call the Calendar API
        today = datetime.datetime.today();
        start = (datetime.datetime(today.year-1, today.month, today.day, 00, 00)).isoformat() + 'Z'
        tomorrow = today + datetime.timedelta(days=740)
        end =  (datetime.datetime(tomorrow.year, tomorrow.month, tomorrow.day, 00, 00)).isoformat() + 'Z'
        now = datetime.datetime.utcnow().isoformat() + 'Z'  # 'Z' indicates UTC time
        primary_events_result = service.events().list(calendarId='primary', timeMin=start, timeMax=end, singleEvents=True, orderBy='startTime').execute()
        # print('Getting the upcoming 10 events')
        # primary_events_result = service.events().list(calendarId="primary", timeMin=now,maxResults=2, singleEvents=True,orderBy='startTime').execute()
        primary_events = primary_events_result.get('items', [])

        # christianHolidaysResult = service.events().list(calendarId="en.christian#holiday@group.v.calendar.google.com", timeMin=start, timeMax=end, singleEvents=True, orderBy='startTime').execute()
        # christianHolidays = christianHolidaysResult.get('items', [])

        primary=[]
        # data.append({"pasadena":{}})
        # Prints the start and name of the next 10 events
        for event in primary_events:
            start=event['start'].get('dateTime', event['start'].get('date'))
            end=event['end'].get('dateTime', event['end'].get('date'))
            summary=event["summary"]
            #data.append({pasadena.start:start,pasadena.end:end,pasadena.summary:event["summary"] })
            primary.append({"start":start,"end":end,"summary":summary})


        return(primary)
        # ev1=json.dumps(primary,separators=(',', ':'))
        # ev2=json.dumps(pasadena,separators=(',', ':'))
    except HttpError as error:
        print('An error occurred: %s' % error)
f = open("/tmp/gcal.json", "w+")
# print("{","\x22primary\x22",":",end="",file=f)
print (json.dumps(calEvents(),separators=(',', ':')),end="",file=f)
f.close()
