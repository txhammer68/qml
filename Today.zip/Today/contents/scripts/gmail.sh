#!/bin/bash
set -e
cd /home/data/projects/gmail
python3 gmail.py
exit
