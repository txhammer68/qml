### Today plasmoid scripts and systemd services/timers setup
### Using scripts and systemd services, as data is used for multiple items -  plasmoids, lockscreen
#### This has to be setup before so the plasmoid will function correctly

```
copy cnn.sh gcal.sh gmail.sh weather.sh to $HOME/.local/bin/
change path in these scripts to match directories below for python scripts
```
```
copy gcalEvents.py  gmail.py to $HOME/gmail/
```
```
copy cnn.service, cnn.timer, gcal.service,gcal.timer,gmail.service,gmail.timer,
weather.service,weather.timer
to /etc/systemd/system
```
#### Setup python enviroment for googe oauth
https://developers.google.com/docs/api/quickstart/python <br>

```
pip install --user --upgrade google-api-python-client google-auth-httplib2 google-auth-oauthlib
pip install --upgrade google-api-python-client google-auth-httplib2 google-auth-oauthlib
```
#### Debian 12 has managed python envrironment add  --break-system-packages to pip command
```
test python scripts w/ python3 gcalEvents.py, verify gcal.json in /tmp directory
```
```
run these to enable systemd services

systemctl enable cnn.service
systemctl enable cnn.timer
systemctl enable gcal.service
systemctl enable gcal.timer
systemctl enable gmail.service
systemctl enable gmail.timer
systemctl enable weather.service
systemctl enable weather.timer
```
Reboot system <br>
Create side panel 340 pixels wide, floating, set to autohide <br>
Place Today plasmoid in this panel, enjoy.
