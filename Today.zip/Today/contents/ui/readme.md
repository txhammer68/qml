## Today Sidebar Plasmoid
#### Plasmoid for KDE 5 Plasma sidebar panel, set to autohide
=================================================
### Logic for data
* GetData.qml provides data to each module below
  * G-Mail unread message count using python backend
  * Calendar Events using python backend
  * CNN Top News Story json feed
  * Stock Market data json feed
  * Sports scores data json feed
  * Weather data json feed

### G-Mail
* Gmail.qml
* Using python to get gmail unread message count
* Events, birthdays, holidays
* Clicking on message count will open gmail.com in web browser

### Calendar Events
* Events.qml
* Holidays & Birthdays

### News
* News.qml
* cnn.com json feed
* Clicking on news will open cnn.com in web browser

### Stock Market Data
* Stocks.qml
* Yahoo Finance API json feed
* Clicking on Market Summary will open finance.yahoo.com in web browser

### Sports Scoreboard
* Scores.qml
* ESPN API
* MLB/NBA
* Clicking on game scoreboard will open game stats on epsn.com in web browser

### Weather
* Weather.qml
* TWC weather API
* Current Conditions/Alerts
* 5 day forecast
* Weather Radar Map
* Using systemd timer/service to download weather data, /tmp used in multiple apps
* Clicking on radar map will open local weather tv station web site in web browser

### System Timer refresh data every 20 mins
* G-Mail (constant)
* News (constant)
* Weather (constant)
* Scores (variable) only when game active
* Stocks (variable) only when market open (M-F)
* Suspend Timer delay after wake from suspend mode
<br>
<br>
<br>

### Scripts folder
* cnn.sh - Download CNN Headlines to cnn.json
* weather.sh - Download weather conditions to weather.json, forecast.json, warnings.json
* gcalEvents.py - Download google calendar events to gcal.json
* gmail.py - Download unread message count to gmail.json
* Corresponding systemd services for each script to automate data retrieval

Notes:using custom system font SF Pro Display, others may break spacing, try using narrow fonts, like Noto Sans

 <img alt="preview" src="preview.png" width="180">
