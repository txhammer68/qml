
## Today Sidebar Plasmoid

### Plasmoid for KDE Plasma sidebar panel, set to autohide

### Logic for data
* GetData.qml
  * G-Mail unread messages
  * Stock Market data
  * Sports scores data
  * Weather data

### G-Mail
* Gmail.qml
* Using python to get gmail unread message count
* Events, birthdays, holidays
* Clicking on message count will open gmail.com in web browser

### Stock Market Data
* Yahoo Finance API
* Stocks.qml
* Clicking on Market Summary will open finance.yahoo.com in web browser

### Sports Scoreboard
* ESPN API
* Scores.qml
* MLB/NBA
* Clicking on game scoreboard will open game stats on epsn.com in web browser

### Weather
* Dark Sky API
* Weather.qml
* Current Conditions
* 5 day forecast
* Weather Radar Map
* Clicking on radar map will open local weather tv station web site in web browser

### System Timer get data every 20 mins
* G-Mail (constant)
* Weather (constant)
* Scores (variable) only when game active
* Stocks (variable) only when market open (M-F)
* Suspend Timer delay after wake from suspend mode
