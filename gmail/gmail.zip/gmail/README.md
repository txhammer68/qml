### Google Workspace Web Ui
#### A Simple webUi for Google Apps
* An MS Outlook interface for Google Apps

#### Notes
* With all the google privacy issues this app will alleviate those fears
* Using python with qml Ui,logins and trackers are separated from normal web browsing
* Login with google id/password to view gmail,gcal,contacts, etc.
* Create app launcher w/ python3 gmail.py
* https://github.com/txhammer68


All trademarks, trade names, or logos mentioned or used are the property of their respective owners. Every effort has been made to properly capitalize, punctuate, identify and attribute trademarks and trade names to their respective owners, including the use of ® and ™ wherever possible and practical. The “Workspace” name and associated logos and marks are trademarks and the property of Google Corporation. All other trademarks are the property of their respective owners.

