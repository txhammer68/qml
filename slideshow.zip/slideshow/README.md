
## QML Photo Slideshow App w/ Ken Burns Pan & Zoom Effects

* Create launcher app w/ python3 slides.py
* Slideshow title uses the file name of the photo
* ESC Quits Slide Show
* Space Pauses Slide Show
* Pause Slide show has a slight delay depeding on length of slide duration timer
* Slideshow repeats automatically after all images cylced
* Hope you find it useful!

[Credit to Bergont Nicolas for original code GitHub](https://gist.github.com/nbergont/8963892)<br>
Although not orginally working, modified to work with my setup<br>
<br>
![Preview](preview.png)
