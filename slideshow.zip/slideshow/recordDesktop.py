#!/bin/env python3

import subprocess
import time
from signal import signal, SIGINT
from sys import exit
def handler(signal_received, frame):
    # Handle any cleanup here
    p.terminate()
    print('SIGINT or CTRL-C detected. Exiting gracefully')
    exit(0)

def set_procname(Newname):
	newname = bytes(Newname, 'utf-8')
	from ctypes import cdll, byref, create_string_buffer
	libc = cdll.LoadLibrary('libc.so.6')    #Loading a 3rd party library C
	buff = create_string_buffer(len(newname)+1) #Note: One larger than the name (man prctl says that)
	buff.value = newname                 #Null terminated string as it should be
	libc.prctl(15, byref(buff), 0, 0, 0) #Refer to "#define" of "/usr/include/linux/prctl.h" for the misterious value 16 & arg[3..5] are zero as the man page says.

set_procname("recordDesktop.py")
time.sleep(2)
p=subprocess.Popen("ffmpeg -y -thread_queue_size 512 -f x11grab -framerate 30 -video_size 1920x1080 -i :0.0+0,0 -f pulse -ac 2  -i 0 -c:v libx264rgb -crf 30 -preset fast -color_range 2 -tune zerolatency $HOME/Videos/Slideshow-$(date +%Y-%m-%d)-$(date +%H.%M.%S).mp4",shell=True)

if __name__ == '__main__':
    # Tell Python to run the handler() function when SIGINT is recieved
    signal(SIGINT, handler)
    print('Running. Press CTRL-C to exit.')
    while True:
        pass
