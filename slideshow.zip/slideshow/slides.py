#!/bin/env python3

import os
import sys
from signal import signal, SIGINT
from pydbus import SessionBus
from sys import exit
from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QIcon,QGuiApplication
from PyQt5.QtWidgets import QApplication
from PyQt5.QtQml import QQmlApplicationEngine
from PyQt5.QtCore import QProcess

CURRENT_DIR = os.path.dirname(os.path.realpath(__file__))

# ***********  python code to launch qml slide show ***********

def handler(signal_received, frame):
    notifications.UnInhibit(cookie)  ## reset back initial states
    lockScreen.UnInhibit(cookie1)
    exit(0)

def set_procname(Newname):
	newname = bytes(Newname, 'utf-8')
	from ctypes import cdll, byref, create_string_buffer
	libc = cdll.LoadLibrary('libc.so.6')    #Loading a 3rd party library C
	buff = create_string_buffer(len(newname)+1) #Note: One larger than the name (man prctl says that)
	buff.value = newname                 #Null terminated string as it should be
	libc.prctl(15, byref(buff), 0, 0, 0) #Refer to "#define" of "/usr/include/linux/prctl.h" for the misterious value 16 & arg[3..5] are zero as the man page says.

set_procname("SlideShow")
bus = SessionBus()
notifications = bus.get("org.freedesktop.Notifications", "/org/freedesktop/Notifications")
lockScreen = bus.get("org.freedesktop.ScreenSaver", "/ScreenSaver")
cookie=notifications.Inhibit("", "", {}) ## prevent notifications
cookie1=lockScreen.Inhibit("","")        ## prevent lockscreen/screensavers
if __name__ == "__main__":
    app = QApplication(sys.argv)
    engine = QQmlApplicationEngine()
    # engine.load(QUrl.fromLocalFile(os.path.join(CURRENT_DIR, "slides.qml")))
    engine.load(os.path.join(os.path.dirname(__file__), "slides.qml"))
    app.setWindowIcon(QIcon(os.path.join(CURRENT_DIR, "slides.png")))
    if not engine.rootObjects():
        signal(SIGINT, handler)
        sys.exit(-1)
    sys.exit(app.exec_())
